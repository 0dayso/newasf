<?php
header("Pragma: no-cache");
require 'common/common.php';
require 'user.class.php';

$user=new user;
$rs=$user->insert_all('');

print_r($rs);
echo $user->getError();
?>