<?php
class asmsBase{
    private  $error;
    Public   $db_prefix;

    function __construct(){
        $this->db_prefix=C('DB_PREFIX');
    }

    function getError($err=''){
        if($err) $this->error=$err;
        return $this->error;
    }

    function setError($err){
        if($err) $this->error=$err;
        return $this->error;
    }

}

?>