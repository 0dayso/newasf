<?php
return array(
    //数据库
    'DB_TYPE'			=>	'Mysql',
    'DB_HOST'			=>	'localhost',
    'DB_NAME'			=>	'asms',
    'DB_USER'			=>	'root',
    'DB_PWD'			=>	'77169',
    'DB_PORT'			=>	'',
    'DB_PREFIX'			=>	'asms_',
	//数据库
	'DX_DB_TYPE'			=>	'Mysql',
    'DX_DB_HOST'			=>	'localhost',
    'DX_DB_NAME'			=>	'vedb',
    'DX_DB_USER'			=>	'vesms',
    'DX_DB_PWD'			=>	'Zg#v$9Ml1',
    'DX_DB_PORT'			=>	'',
    'DX_DB_PREFIX'			=>	'asf_',

    'ASMS_HOST'=>'http://121.8.201.163:8150/',
	'ASMS_AUTH'=>'6000',
	'ASMS_PWD'=>'77169',

);


?>